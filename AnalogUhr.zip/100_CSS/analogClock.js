// JavaScript für die analoge Uhr

// Funktion zur Aktualisierung der Uhrzeiger basierend auf der aktuellen Zeit
function updateClock() {
    const now = new Date();
  
    // Hole die aktuelle Stunde, Minute und Sekunde
    const seconds = now.getSeconds();
    const minutes = now.getMinutes();
    const hours = now.getHours();
  
    // Berechne die Drehwinkel für jeden Zeiger
    const secondsDegrees = (seconds / 60) * 360 + 260; // Um 90° nach rechts verschoben
    const minutesDegrees = (minutes / 60) * 360 + (seconds / 60) * 6 + 260;
    const hoursDegrees = (hours / 12) * 360 + (minutes / 60) * 30 + 260;
  
    // Wähle jeden Zeiger aus
    const secondHand = document.querySelector('.second-hand');
    const minHand = document.querySelector('.min-hand');
    const hourHand = document.querySelector('.hour-hand');
  
    // Setze die Drehung der Zeiger
    secondHand.style.transform = `rotate(${secondsDegrees}deg)`;
    minHand.style.transform = `rotate(${minutesDegrees}deg)`;
    hourHand.style.transform = `rotate(${hoursDegrees}deg)`;
}
  
// Aktualisiere die Uhr jede Sekunde
setInterval(updateClock, 1000);
  
// Initialisiere die Uhr beim Laden der Seite
updateClock();
